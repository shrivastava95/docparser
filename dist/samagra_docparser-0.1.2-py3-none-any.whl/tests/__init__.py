import docparser

def test_sample():
    assert True