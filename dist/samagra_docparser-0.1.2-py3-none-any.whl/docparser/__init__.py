# from .sample import test_function
from .parser import PdfParser, DictParser, Page, clip_model_name, tesseract_config, parser_mode